﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab19
{
    internal class Computer
    {
        public string Id { get; set; }
        public string NameMark { get; set; }
        public string TypeProcessor { get; set; }
        public double Frequency { get; set; }
        public int RAM { get; set; }
        public int VHardDisk { get; set; }
        public int VRAM { get; set; }
        public double CostComputer { get; set; }
        public int Quantity { get; set; }
    }
}
