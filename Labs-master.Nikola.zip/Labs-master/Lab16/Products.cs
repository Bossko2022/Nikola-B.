﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab16
{
    class Products
    {
        public int codeProduct { get; set; }
        public string nameProduct { get; set; }
        public double costProduct { get; set; }

    }
}
