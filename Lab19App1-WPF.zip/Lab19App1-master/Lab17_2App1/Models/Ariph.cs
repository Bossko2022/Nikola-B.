﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab17_2App1.Models
{
    static class Ariph
    {
        public static double Add(int a) => 2 * Math.PI * a;
    }
}
