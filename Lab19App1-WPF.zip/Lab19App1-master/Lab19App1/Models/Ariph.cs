﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab19App1.Models
{
   static class Ariph
    {
       public static int Add(int a, int b) => a + b;
    }
}
